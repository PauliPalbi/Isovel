# Isovel

The goal is to create a package that draw isovelocity curves over ALMA gas images. 

The isovelocities follow a Kepplerian rotation. 

The starting point is from vivis code. 

To test it we are going to use DSHARP disks.  
https://bulk.cv.nrao.edu/almadata/lp/DSHARP/
