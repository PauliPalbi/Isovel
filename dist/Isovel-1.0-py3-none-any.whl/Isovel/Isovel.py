# This to start documentation
import numpy as np
from scipy.ndimage.interpolation import rotate

def mult(a,b):
    """
    multiplication

    Args: 
        a (float): first number
        b (float): second number
    Returns:
        float: multiplication
    """
    return a*b